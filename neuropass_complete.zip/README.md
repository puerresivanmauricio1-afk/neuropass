# NeuroPass

App de flashcards medicas.

## Como compilar APK

1. Ve a **Actions** en GitHub
2. Click en **Build APK**
3. Click **Run workflow**
4. Espera 5 minutos
5. Descarga el APK desde Artifacts
