package com.example.neuropass

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
