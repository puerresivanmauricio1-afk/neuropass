import 'package:flutter_test/flutter_test.dart';
import 'package:neuropass/main.dart';

void main() {
  testWidgets('App launches', (WidgetTester tester) async {
    await tester.pumpWidget(const NeuroPassApp());
    expect(find.text('NeuroPass'), findsOneWidget);
  });
}
